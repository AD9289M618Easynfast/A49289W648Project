<html <?php language_attributes(); ?>>
    <head <?php
    global $imagePath;
    ?>>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <title><?php wp_title(''); ?></title>
        <?php wp_head(); ?>
    </head>
    <body bgcolor=#ecf4f6 leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

        <div style="background:url(<?php echo $imagePath ?>x_02.jpg) top repeat-x;">
            <center>
                <table border="0" cellpadding="0" cellspacing="0" width=878>
                    <tr>
                        <td><img src="<?php echo $imagePath ?>header.jpg" alt=""></td>
                    </tr>