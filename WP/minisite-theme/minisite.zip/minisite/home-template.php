<?php
/* 
 * Template Name: Home Minisite
 */
global $imagePath;
include 'home-template-field.php';
global $template1;
get_header();
echo $template1;
?>
<?php
get_footer();
?>
