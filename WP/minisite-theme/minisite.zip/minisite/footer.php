<!--footer-->
<?php
    global $imagePath;
    ?>
<Tr><td style="background:url(<?php echo $imagePath ?>x_12.jpg);width:878px;height:157px;">


        <div style="padding-left:370px;">
            <div  class=footer>

                <a href="#">Contact</a> - <a href="#">Privacy Policy</a> - <a href="#">Terms Of Use</a> - <a href="#">Earnings Disclaimer</a> - <a href="#">Affiliates</a>
                <BR>
                Copyright 2014, USBIncome.com. All Rights Reserved.

            </div>


        </div>

    </td></tr>

</table>

</div>
</div>
</center>

</div>


<?php wp_footer(); ?>
</body>
</html>