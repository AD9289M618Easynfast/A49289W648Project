<?php

/* Template Name: Home */
get_header();
get_sidebar();
get_footer();
