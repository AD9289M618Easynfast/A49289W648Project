<?php

if (is_active_sidebar('uplifts-widget-content')) {
    dynamic_sidebar('uplifts-widget-content');
}