</div>
<div class="footer-wrap">
 <p>Text HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText HereText HereText Here
    HereText HereText HereText HereText HereText 
</p>
<div class="footer-copyright">Copyright © 2013 Puamax.All rights reserved</div>
</div>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>