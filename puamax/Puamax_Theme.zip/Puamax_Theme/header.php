<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Puamax</title>
</head>
<body<?php
     global $imagePath;
 ?>>
    <?php wp_head(); ?>
	<div id="wrapper">
        <div id="container">
         <div class="header-wrap">
             <div class="header">
                 <a href="#" class="site-banner">
                     <img src="<?php echo  $imagePath; ?>logo.png"  width="226" height="67" />
                 </a>
                 <img  src="<?php echo  $imagePath; ?>img-head-product.png" class="image-header-product" />
                 <img src="<?php echo  $imagePath; ?>head-label.png" class="arrow-right" />
             </div>
         </div>
         <div class="content-wrap">